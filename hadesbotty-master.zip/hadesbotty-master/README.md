# Hades's Star Tech Bot

A Discord Bot born to user manage data for the mobile game **Hades's Star**.

## Main Commands:

**!tech** : Manages tech data
  - `set`    : set individual or batch techs
  - `get`    : get a user's tech list
  - `search` : search @role|all users for a single tech
  - `score`  : gets the score for @role|all users

**!techreport**: Report on various users/techs 

**!roster** : Manages the guild's WhiteStar roster

**!redstar** : Manages queues for public redstar's

**!activity** : Follow up on members activity status (Level/Influence)

**!time** : sets and gets Local Time for all|@role|@user 

**!lastseen** : last time a user was seen

**!whitelist** : A way to set your tech as private.

===============================================================================
*This was build upon the [Idiots Guide Bot](https://github.com/An-Idiots-Guide/guidebot.git). :+1: Thank you for the great guide*
